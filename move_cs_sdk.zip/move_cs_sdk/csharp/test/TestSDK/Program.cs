﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tx2.Move;
using Tx2.Move.Action;
using Tx2.Move.DataObject;
using Tx2.Move.Utils;

namespace TestSDK
{
    class Program
    {
        //private static string SecurityKey = "2AA6D2AF09FAAAE1FDC9CED9DA153B78";
        //private static string ConsumerCode = "000000000000086";
        //private static string SecurityKey = "37107E8778FB7A93";
        //private static string ConsumerCode = "000000000000076";
        private static string SecurityKey = "2116DD7F74611816";
        private static string ConsumerCode = "000000000000049";
        private static string LogFilePath = "test.xml";

        public static ApiMoveContext context;
        public static bool close = false;
        public static bool configured = false;

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome into the console interface for the testing of POS API SDK !");
            Console.WriteLine("Please provide some basic information before to start\n");
            Console.WriteLine("Path for log file (default: " + LogFilePath + "):");
            SetStringIfInputNotNull(ref LogFilePath);

            DualOut.Init(LogFilePath);

            Start();

            while (!close)
            {
                if (context != null && configured)
                {
                    Menu();
                }
                else
                {
                    Start();
                }
            }

            Console.WriteLine("Done");
            Console.ReadKey();
        }

        static void Start()
        {
            Console.WriteLine("\n* --------------- * CONFIGURATION * --------------- *\n");
            Console.WriteLine("Please enter your Customer information");
            Console.WriteLine("SecurityKey (default: " + SecurityKey + ")");
            SetStringIfInputNotNull(ref SecurityKey);
            Console.WriteLine("ConsumerCode (default: " + ConsumerCode + ")");
            SetStringIfInputNotNull(ref ConsumerCode);

            try
            {
                context = new ApiMoveContext(ConsumerCode, SecurityKey);
                Console.WriteLine("Context Created");
                configured = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Context not created, please retry");
            }
        }

        static void Menu()
        {
            Console.WriteLine("\n* --------------- * MENU * --------------- *\n");
            Console.WriteLine("Please choose the next action");
            Console.WriteLine("1. GetVoucher");
            Console.WriteLine("2. SendVoucher");
            Console.WriteLine("3. ResendVoucher");
            Console.WriteLine("4. TrashVoucher");
            Console.WriteLine("5. QueryVoucherStatus");
            Console.WriteLine("6. CheckOrderStatus");
            Console.WriteLine("7. GetMultiVouchersV2");
            Console.WriteLine("8. Change Configuration");
            Console.WriteLine("9. Close");
            Console.WriteLine("10. Decrypt the SOAP API Getvoucher Response");
            Console.WriteLine("11. GetVoucherV3");
            Console.WriteLine("12. GetMultiVouchersV4");

            string str = "";
            int value = 0;
            while (value < 1 || value > 14)
            {
                Console.WriteLine("\nEnter a valid value");
                str = Console.ReadLine();
                try
                {
                    value = int.Parse(str);
                }
                catch
                {
                    value = 0;
                }
            }

            switch (value)
            {
                case 1:
                    GetVoucher();
                    break;
                case 2:
                    SendVoucher();
                    break;
                case 3:
                    ResendVoucher();
                    break;
                case 4:
                    TrashVoucher();
                    break;
                case 5:
                    QueryVoucherStatus();
                    break;
                case 6:
                    CheckOrderStatus();
                    break;
                case 7:
                    GetMultiVouchersV2();
                    break;
                case 8:
                    configured = false;
                    break;
                case 9:
                    close = true;
                    break;
                case 10:
                    DecryptResponse();
                    break;
                case 11:
                    GetVoucherV3();
                    break;
                case 12:
                    GetMultiVouchersV4();
                    break;
                default:
                    Console.WriteLine("\n/!\\ /!\\ Error Unexpected area reached /!\\ /!\\\n");
                    break;
            }
        }

        static void GetVoucher()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * GET VOUCHER * ----- *\n");
            try
            {
                string OrderNumber = "202006051917";
                string ProductCode = "AGDTHEDP001";
                string ClientOrderNumber = "";
                string RecipientSms = "";
                string RecipientEmail = "";
                string RecipientMemo = "";
                string RecipientName = "";
                string EmailSubject = "";
                string ActiveDate = "";
                string ExpiryDate = "";

                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("ProductCode (default: " + ProductCode + ")");
                SetStringIfInputNotNull(ref ProductCode);
                Console.WriteLine("ClientOrderNumber (default: " + ClientOrderNumber + ")");
                SetStringIfInputNotNull(ref ClientOrderNumber);
                Console.WriteLine("RecipientSms (default: " + RecipientSms + ")");
                SetStringIfInputNotNull(ref RecipientSms);
                Console.WriteLine("RecipientEmail (default: " + RecipientEmail + ")");
                SetStringIfInputNotNull(ref RecipientEmail);
                Console.WriteLine("RecipientMemo (default: " + RecipientMemo + ")");
                SetStringIfInputNotNull(ref RecipientMemo);
                Console.WriteLine("RecipientName (default: " + RecipientName + ")");
                SetStringIfInputNotNull(ref RecipientName);
                Console.WriteLine("EmailSubject (default: " + EmailSubject + ")");
                SetStringIfInputNotNull(ref EmailSubject);
                Console.WriteLine("ActiveDate (default: " + ActiveDate + ")");
                SetStringIfInputNotNull(ref ActiveDate);
                Console.WriteLine("ExpiryDate (default: " + ExpiryDate + ")");
                SetStringIfInputNotNull(ref ExpiryDate);

                Nullable<DateTime> ActiveDateTime = null;
                Nullable<DateTime> ExpiryDateTime = null;

                if(ActiveDate != "")
                {
                    ActiveDateTime = DateTime.Parse(ActiveDate);
                }
                if(ExpiryDate != "")
                {
                    ExpiryDateTime = DateTime.Parse(ExpiryDate);
                }

                GetVoucherTransaction transaction2 = context.GetVoucher(
                    OrderNumber,
                    ProductCode,
                    ClientOrderNumber,
                    RecipientSms,
                    RecipientEmail,
                    RecipientMemo,
                    RecipientName,
                    EmailSubject,
                    ActiveDateTime,
                    ExpiryDateTime
                );

                Console.WriteLine(XmlSerializer<GetVoucherResponseDto>.ObjectToXml(transaction2.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void GetVoucherV3()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * GET VOUCHER * ----- *\n");
            try
            {
                string OrderNumber = "202002131541";
                string ProductCode = "GONVDDMMYY01";
                string ClientOrderNumber = "202002211600";
                string RecipientSms = "";
                string RecipientEmail = "";
                string RecipientMemo = "";
                string RecipientName = "";
                string EmailSubject = "";
                string ActiveDate = "";
                string ExpiryDate = "";

                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("ProductCode (default: " + ProductCode + ")");
                SetStringIfInputNotNull(ref ProductCode);
                Console.WriteLine("ClientOrderNumber (default: " + ClientOrderNumber + ")");
                SetStringIfInputNotNull(ref ClientOrderNumber);
                Console.WriteLine("RecipientSms (default: " + RecipientSms + ")");
                SetStringIfInputNotNull(ref RecipientSms);
                Console.WriteLine("RecipientEmail (default: " + RecipientEmail + ")");
                SetStringIfInputNotNull(ref RecipientEmail);
                Console.WriteLine("RecipientMemo (default: " + RecipientMemo + ")");
                SetStringIfInputNotNull(ref RecipientMemo);
                Console.WriteLine("RecipientName (default: " + RecipientName + ")");
                SetStringIfInputNotNull(ref RecipientName);
                Console.WriteLine("EmailSubject (default: " + EmailSubject + ")");
                SetStringIfInputNotNull(ref EmailSubject);
                Console.WriteLine("ActiveDate (default: " + ActiveDate + ")");
                SetStringIfInputNotNull(ref ActiveDate);
                Console.WriteLine("ExpiryDate (default: " + ExpiryDate + ")");
                SetStringIfInputNotNull(ref ExpiryDate);

                Nullable<DateTime> ActiveDateTime = null;
                Nullable<DateTime> ExpiryDateTime = null;

                if (ActiveDate != "")
                {
                    ActiveDateTime = DateTime.Parse(ActiveDate);
                }
                if (ExpiryDate != "")
                {
                    ExpiryDateTime = DateTime.Parse(ExpiryDate);
                }

                GetVoucherV3Transaction transaction3 = context.GetVoucherV3(
                    OrderNumber,
                    ProductCode,
                    ClientOrderNumber,
                    RecipientSms,
                    RecipientEmail,
                    RecipientMemo,
                    RecipientName,
                    EmailSubject,
                    ActiveDateTime,
                    ExpiryDateTime
                );

                Console.WriteLine(XmlSerializer<GetVoucherV3ResponseDto>.ObjectToXml(transaction3.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        public static void GetMultiVouchersV2()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * GET MULTI VOUCHERS V2 * ----- *\n");
            try
            {
                string OrderNumber = "202006051917";
                string ClientOrderNumber = "";
                string ProductCode = "AGDTHEDP001";
                string Quantity = "1";
                string SoldPrice = "100.0000"
;
                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("ClientOrderNumber (default: " + ClientOrderNumber + ")");
                SetStringIfInputNotNull(ref ClientOrderNumber);
                Console.WriteLine("ProductCode (default: " + ProductCode + ")");
                SetStringIfInputNotNull(ref ProductCode);
                Console.WriteLine("Quantity (default: " + Quantity + ")");
                SetStringIfInputNotNull(ref Quantity);
                Console.WriteLine("SoldPrice (default: " + SoldPrice + ")");
                SetStringIfInputNotNull(ref SoldPrice);

                GetMultiVouchersV2Transaction transaction = context.GetMultiVouchersV2(
                    OrderNumber,
                    ClientOrderNumber,
                    ProductCode,
                    int.Parse(Quantity),
                    float.Parse(SoldPrice)
                );

                Console.WriteLine(XmlSerializer<GetMultiVouchersResponseDtoV2>.ObjectToXml(transaction.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        public static void GetMultiVouchersV4()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * GET MULTI VOUCHERS V4 * ----- *\n");
            try
            {
                string OrderNumber = "202006051917";
                string ClientOrderNumber = "";
                string ProductCode = "AGDTHEDP001";
                string Quantity = "1";
                string SoldPrice = "100.0000"
;
                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("ClientOrderNumber (default: " + ClientOrderNumber + ")");
                SetStringIfInputNotNull(ref ClientOrderNumber);
                Console.WriteLine("ProductCode (default: " + ProductCode + ")");
                SetStringIfInputNotNull(ref ProductCode);
                Console.WriteLine("Quantity (default: " + Quantity + ")");
                SetStringIfInputNotNull(ref Quantity);
                Console.WriteLine("SoldPrice (default: " + SoldPrice + ")");
                SetStringIfInputNotNull(ref SoldPrice);

                GetMultiVouchersV4Transaction transaction12 = context.GetMultiVouchersV4
                    ( OrderNumber,
                    ClientOrderNumber,
                    ProductCode,
                    int.Parse(Quantity),
                    float.Parse(SoldPrice)
                );

                Console.WriteLine(XmlSerializer<GetMultiVouchersV4ResponseDto>.ObjectToXml(transaction12.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }
        static void SendVoucher()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * SEND VOUCHER * ----- *\n");
            try
            {
                string OrderNumber = "201811130346";
                string ProductCode = "ZALVBSGD10";
                string ClientOrderNumber = "";
                string RecipientSms = "";
                string RecipientEmail = "";
                string RecipientMemo = "";
                string RecipientName = "";
                string EmailSubject = "";
                string ActiveDate = "";
                string ExpiryDate = "";

                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("ProductCode (default: " + ProductCode + ")");
                SetStringIfInputNotNull(ref ProductCode);
                Console.WriteLine("ClientOrderNumber (default: " + ClientOrderNumber + ")");
                SetStringIfInputNotNull(ref ClientOrderNumber);
                Console.WriteLine("RecipientSms (default: " + RecipientSms + ")");
                SetStringIfInputNotNull(ref RecipientSms);
                Console.WriteLine("RecipientEmail (default: " + RecipientEmail + ")");
                SetStringIfInputNotNull(ref RecipientEmail);
                Console.WriteLine("RecipientMemo (default: " + RecipientMemo + ")");
                SetStringIfInputNotNull(ref RecipientMemo);
                Console.WriteLine("RecipientName (default: " + RecipientName + ")");
                SetStringIfInputNotNull(ref RecipientName);
                Console.WriteLine("EmailSubject (default: " + EmailSubject + ")");
                SetStringIfInputNotNull(ref EmailSubject);
                Console.WriteLine("ActiveDate (default: " + ActiveDate + ")");
                SetStringIfInputNotNull(ref ActiveDate);
                Console.WriteLine("ExpiryDate (default: " + ExpiryDate + ")");
                SetStringIfInputNotNull(ref ExpiryDate);

                Nullable<DateTime> ActiveDateTime = null;
                Nullable<DateTime> ExpiryDateTime = null;

                if (ActiveDate != "")
                {
                    ActiveDateTime = DateTime.Parse(ActiveDate);
                }
                if (ExpiryDate != "")
                {
                    ExpiryDateTime = DateTime.Parse(ExpiryDate);
                }

                /*
                // Different way of processing the request
                SendVoucherTransaction transaction = new SendVoucherTransaction();
                transaction.Request.OrderNumber = OrderNumber;
                transaction.Request.ProductCode = ProductCode;
                transaction.Request.ClientOrderNumber = ClientOrderNumber;
                transaction.Request.RecipientSms = RecipientSms;
                transaction.Request.RecipientEmail = RecipientEmail;
                transaction.Request.RecipientMemo = RecipientMemo;
                transaction.Request.RecipientName = RecipientName;
                transaction.Request.EmailSubject = EmailSubject;
                transaction.Request.ActiveDate = ExpiryDateTime;
                transaction.Request.ExpiryDate = ExpiryDateTime;
                RequestDto requestDto = transaction.CreateRequestDto();

                Console.WriteLine(" ---------- RequestDto:");
                Console.WriteLine(XmlSerializer<RequestDto>.ObjectToXml(requestDto) + "\n\n");

                ResponseOutDto responseDto = context.ExecuteRequest(requestDto);

                Console.WriteLine(" ---------- ResponseDto:");
                Console.WriteLine(XmlSerializer<ResponseOutDto>.ObjectToXml(responseDto) + "\n\n");

                transaction.ParseResponseOutDto(responseDto);
                */

                SendVoucherTransaction transaction4 = context.SendVoucher(
                    OrderNumber,
                    ProductCode,
                    ClientOrderNumber,
                    RecipientSms,
                    RecipientEmail,
                    RecipientMemo,
                    RecipientName,
                    EmailSubject,
                    ActiveDateTime,
                    ExpiryDateTime
                );

                Console.WriteLine(XmlSerializer<SendVoucherResponseDto>.ObjectToXml(transaction4.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void CheckOrderStatus()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * CHECK ORDER STATUS * ----- *\n");
            try
            {
                string OriginalRequestGuid = "";

                Console.WriteLine("OriginalRequestGuid (default: " + OriginalRequestGuid + ")");
                SetStringIfInputNotNull(ref OriginalRequestGuid);

                /*
                // Different way of processing the request
                CheckOrderStatusTransaction transaction = new CheckOrderStatusTransaction();
                transaction.Request.OriginalRequestGuid = System.Guid.Parse(OriginalRequestGuid);
                RequestDto requestDto = transaction.CreateRequestDto();

                Console.WriteLine("RequestDto:");
                Console.WriteLine(XmlSerializer<RequestDto>.ObjectToXml(requestDto) + "\n\n");

                ResponseOutDto responseDto = context.ExecuteRequest(requestDto);

                Console.WriteLine("ResponseDto:");
                Console.WriteLine(XmlSerializer<ResponseOutDto>.ObjectToXml(responseDto) + "\n\n");

                transaction.ParseResponseOutDto(responseDto);
                */

                CheckOrderStatusTransaction transaction5 = context.CheckOrderStatus(OriginalRequestGuid);

                Console.WriteLine(XmlSerializer<CheckOrderStatusResponseDto>.ObjectToXml(transaction5.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void TrashVoucher()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * TRASH VOUCHER * ----- *\n");
            try
            {
                string VoucherGuid = "";

                Console.WriteLine("VoucherGuid (default: " + VoucherGuid + ")");
                SetStringIfInputNotNull(ref VoucherGuid);

                TrashVoucherTransaction transaction6 = context.TrashVoucher(VoucherGuid);

                Console.WriteLine(XmlSerializer<ResponseDto>.ObjectToXml(transaction6.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void ResendVoucher()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * RESEND VOUCHER * ----- *\n");
            try
            {
                string OrderNumber = "201811130346";
                string VoucherGuid = "";
                string DeliveryMethod = "2";

                Console.WriteLine("OrderNumber (default: " + OrderNumber + ")");
                SetStringIfInputNotNull(ref OrderNumber);
                Console.WriteLine("VoucherGuid (default: " + VoucherGuid + ")");
                SetStringIfInputNotNull(ref VoucherGuid);
                Console.WriteLine("DeliveryMethod (1: Sms, 2:Email)(default: " + DeliveryMethod + ")");
                SetStringIfInputNotNull(ref DeliveryMethod);
                VoucherDeliveryMethod method = (DeliveryMethod == "1") ? VoucherDeliveryMethod.Sms : VoucherDeliveryMethod.Email;

                ResendVoucherTransaction transaction7 = context.ResendVoucher(OrderNumber, VoucherGuid, method);

                Console.WriteLine(XmlSerializer<ResponseDto>.ObjectToXml(transaction7.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void QueryVoucherStatus()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * QUERY VOUCHER STATUS * ----- *\n");
            try
            {
                string VoucherGuid = "";

                Console.WriteLine("VoucherGuid (default: " + VoucherGuid + ")");
                SetStringIfInputNotNull(ref VoucherGuid);

                QueryVoucherStatusTransaction transaction = context.QueryVoucherStatus(VoucherGuid);

                Console.WriteLine(XmlSerializer<ResponseDto>.ObjectToXml(transaction.Response));
            }
            catch (Exception e)
            {
                File.AppendAllText(LogFilePath, e.Message);
                Console.WriteLine(e.Message);
            }
        }

        static void DecryptResponse()
        {
            Console.WriteLine("\n* ---------- * ACTION * ---------- *\n");
            Console.WriteLine("* ----- * DECRYPT THE GET VOUCHER SOAP API RESPONSE FOR INVESTIGATIONS * ----- *\n");
            //Console.WriteLine("Key in SOAP API Response String");
            //String APIRes = Console.ReadLine();
            String APIRes = "kRQ0Lc/uQPJNae3iwzk+QCrv8cNHD185U7Vc7zTFx/d0dOpxLqgVfBM2EbYNxvnlg111B2JdWjsykNpPLHehjOwv2JO6SoUZACRV8tM+kggagPkrYlmr6Hsu2XcAm3Ld9bKyeTWHCZ2tXbhmX9KpqTB1MwQWfagaj/MnROX6XDNhiTC5FBXIQ/4NNz+/E8bEztYkNYSj42ofQlzQpEJ/VEvF5nCQn2r/eCsNuwB+XIJrCKamgSsvLvySUptOHHrKKEV87/fJuiLWcztgclQHKdH0QNTNBqFNXeHeC3HeP2EFkLNQZhwoTs+0U+QEO+4mwECFy1OQjq9kxR6h8xWRhqlfGqOcaJhMktUwvtouUzquIlw+X2PtsUW2YNvi4jYbuJJIayh3OswKnT59F+a3fxgOcm5fDG86KppkNSkj7R5AZdzZe4WSbhHGCDKQA7cwWbW1RSZkktCKq5jYZyJb0FUzpsdef1ffB3Z6ZrRk+bAW2L133OquzkvlUSeAipVt/2I9KMfjoJ7SaukEF11u+xFEBEYCBVNxmQU/PL5f4Lc42JdQzRmqcmvgMiJtTDGp3myFXw3CWFyzmv6TaMvJDm2i3AZG+f31DwNKQ/5OM55SDLQWE43vzuTEui73zSWwS7yl8EVazURiX6Dnb7q2czHMHCpAXWqC5TlcoG/KdpAER/NmalAptk7AG0H44xY/s5BhVuFJCnMKlr7ikY1q9HHamzmK4VjFzAbWkqfeMicoEdDJGQsy8qQSkS5u8BxzXgLu5A0vjT91hcSYDuvnSqA6/Y7ugzcB3p295L1kR5Eypafx+lxfmMPY1kAJzLUHYaUChERVY05bJCSk5tpwpU42IU5ljcbnqy0ZSAraUQgcJ0JOsKWPZUwlEIg/oQY8nEHb/MlEZNa7O/xghzo5qp7aJoI+cuL/aKSv4x9R52VtnAfYu94zEUmWH3DDjrTl1xHxuRtvb7e8xw+VdwR+kSKSq2nbabU8AdHD0JmMOjOQHdJeiIyysDeo0NLTem0K++PaTQsR5erDc5VzAr/CbtO1nx9DREoZvc+yHbVOlRA/9LrUyoXqLfpBvjCdyx6b";
            String ConsKey = "81ABDB43475D540F6A53E50DCCF76841";


            //Console.WriteLine("\nKey in AES or DES\n");
            //int Algo =int.Parse( Console.ReadLine());
            //Console.WriteLine("\nKey in Consumer AES or DES\n");
            //String KeyType = Console.ReadLine();
            String APIResponseDecrypt = DesHelper.Decrypt(APIRes, ConsKey, context.Encryption );
            //String APIResponseDecrypt = DesHelper.Decrypt(APIRes, ConsKey, context.SecurityKey = SecurityAlgorithm.AES);
            //String APIResponseDecrypt = DesHelper.DecryptVivek(APIRes, ConsKey, context.VivekEncryption);
            Console.WriteLine("Decrypted Text:" + APIResponseDecrypt);
        }
        static private bool SetStringIfInputNotNull(ref string value)
        {
            string temp = Console.ReadLine();
            if (temp != string.Empty)
            {
                value = temp;
                return true;
            }
            return false;
        }
    }

    public static class DualOut
    {
        private static TextWriter _current;
        private static string LogFilePath;

        private class OutputWriter : TextWriter
        {
            public override Encoding Encoding
            {
                get
                {
                    return _current.Encoding;
                }
            }

            public override void WriteLine(string value)
            {
                _current.WriteLine(value);
                File.AppendAllLines(LogFilePath, new string[] { value });
            }
        }

        public static void Init(string logFilePath)
        {
            LogFilePath = logFilePath;
            File.WriteAllText(LogFilePath, string.Empty);
            _current = Console.Out;
            Console.SetOut(new OutputWriter());
        }
    }
}
