﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// 
    /// </summary>
    public class GetMultiVouchersV2Transaction : Transaction<GetMultiVouchersRequestDto, GetMultiVouchersResponseDtoV2>
    {
        /// <summary>
        /// Operation.Code.GetMultiVouchersV2
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.GetMultiVouchersV2; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}