﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Get Voucher Transactions
    /// </summary>
    public class GetVoucherV3Transaction : Transaction<GetVoucherV3RequestDto, GetVoucherV3ResponseDto>
    {
        /// <summary>
        /// Operation.Code.GetVoucherV4
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.GetVoucherV3; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
