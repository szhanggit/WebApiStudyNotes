﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Query Voucher Status Transactions
    /// </summary>
    public class QueryVoucherStatusTransaction : Transaction<QueryVoucherStatusRequestDto, QueryVoucherStatusResponseDto>
    {
        /// <summary>
        /// Operation.Code.QueryVoucherStatus
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.QueryVoucherStatus; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
