﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Check Order Status Transactions
    /// </summary>
    public class CheckOrderStatusTransaction : Transaction<CheckOrderStatusRequestDto, CheckOrderStatusResponseDto>
    {
        /// <summary>
        /// Operation.Code.CheckOrderStatus
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.CheckOrderStatus; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
