﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Trash Voucher Transactions
    /// </summary>
    public class TrashVoucherTransaction : Transaction<VoucherGuidRequestDto, ResponseDto>
    {
        /// <summary>
        /// Operation.Code.TrashVoucher
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.TrashVoucher; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
