﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Get Voucher Transactions
    /// </summary>
    public class GetVoucherTransaction : Transaction<GetVoucherRequestDto, GetVoucherResponseDto>
    {
        /// <summary>
        /// Operation.Code.GetVoucher
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.GetVoucher; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
