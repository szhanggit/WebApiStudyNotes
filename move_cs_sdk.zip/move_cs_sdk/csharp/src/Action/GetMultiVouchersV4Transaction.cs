﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    public class GetMultiVouchersV4Transaction : Transaction<GetMultiVouchersV4RequestDto,GetMultiVouchersV4ResponseDto>
    {
        /// <summary>
        /// Operation.Code.GetMultiVouchersV4
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.GetMultiVouchersV4; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
