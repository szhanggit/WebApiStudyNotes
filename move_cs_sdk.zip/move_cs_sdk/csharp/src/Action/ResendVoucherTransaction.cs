﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Resend Voucher Transactions
    /// </summary>
    public class ResendVoucherTransaction : Transaction<ResendVoucherRequestDto, ResponseDto>
    {
        /// <summary>
        /// Operation.Code.ResendVoucher
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.ResendVoucher; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
