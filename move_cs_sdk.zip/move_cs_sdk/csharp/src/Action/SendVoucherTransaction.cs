﻿using Tx2.Move.DataObject;

namespace Tx2.Move.Action
{
    /// <summary>
    /// For Send Voucher Transactions
    /// </summary>
    public class SendVoucherTransaction : Transaction<SendVoucherRequestDto, SendVoucherResponseDto>
    {
        /// <summary>
        /// Operation.Code.SendVoucher
        /// </summary>
        public override string Code { get { return Utils.Operation.Code.SendVoucher; } }

        /// <summary>
        /// Create RequestDto
        /// </summary>
        /// <returns>RequestDto</returns>
        public override RequestDto CreateRequestDto()
        {
            return base.CreateRequestDtoFromCode(Code);
        }
    }
}
