﻿using System;
using Tx2.Move.DataObject;
using Tx2.Move.Utils;

namespace Tx2.Move.Action
{
    /// <summary>
    /// Generic class for Transactions objects
    /// </summary>
    /// <typeparam name="T1">RequestBase</typeparam>
    /// <typeparam name="T2">ResponseDto</typeparam>
    public abstract class Transaction<T1, T2>
        where T1 : RequestBase, new()
        where T2 : ResponseDto, new()
    {
        /// <summary>
        /// Transaction's request
        /// </summary>
        public T1 Request;

        /// <summary>
        /// Transaction's response
        /// </summary>
        public T2 Response;

        /// <summary>
        /// Transaction's code
        /// </summary>
        public abstract string Code { get; }

        /// <summary>
        /// Locker for transaction
        /// </summary>
        public bool Locker { get; protected set; } = false;

        /// <summary>
        /// Constructor
        /// </summary>
        public Transaction()
        {
            Request = new T1();
            Response = new T2();
        }

        /// <summary>
        /// Constructor from context
        /// </summary>
        /// <param name="context"></param>
        public Transaction(ApiMoveContext context)
        {
            Request = new T1();
            Request.ConsumerCode = context.ConsumerCode;

            Response = new T2();
        }

        /// <summary>
        /// Abstract method to generate the RequestDto of the transaction
        /// </summary>
        /// <returns></returns>
        public abstract RequestDto CreateRequestDto();

        /// <summary>
        /// Create RequestDto for specified code
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public RequestDto CreateRequestDtoFromCode(string code)
        {
            string innerDtoXML = XmlSerializer<T1>.ObjectToXml(Request);

            RequestDto requestDto = new RequestDto()
            {
                OperationCode = code,
                Parameters = innerDtoXML,
                RequestGuid = System.Guid.NewGuid()
            };

            return requestDto;
        }

        /// <summary>
        /// Parse response dto
        /// </summary>
        /// <param name="response"></param>
        public void ParseResponseOutDto(ResponseOutDto response)
        {
            Response = XmlSerializer<T2>.XmlToObject(response.Response);
        }
    }
}
