﻿using System;
using Tx2.Move.Api;
using Tx2.Move.Utils;
using Tx2.Move.Action;
using Tx2.Move.DataObject;

namespace Tx2.Move
{
    /// <summary>
    /// 
    /// </summary>
    public class ApiMoveContext
    {
        /// <summary>
        /// 
        /// </summary>
        public string ConsumerCode { get; protected set; }

        /// <summary>
        /// 
        /// </summary>
        private PublicServiceClient Client;

        private string _SecurityKey;
        /// <summary>
        /// 
        /// </summary>
        public string SecurityKey
        {
            get
            {
                return _SecurityKey;
            }
            protected set
            {
                if(value.Length == 16)
                {
                    Encryption = SecurityAlgorithm.DES;
                }
                else if(value.Length == 32)
                {
                    Encryption = SecurityAlgorithm.AES;
                }
                else
                {
                    throw new Exception("SecurityKey size is not valid format");
                }
                _SecurityKey = value;
            }
        }

        private string _VivekSecurityKey;
        public string Conskey
        {
            get
            {
                return _VivekSecurityKey;
            }
            protected set
            {
                if (value.Length == 16)
                {
                    VivekEncryption = SecurityAlgorithm.DES;
                }
                else if (value.Length == 32)
                {
                    VivekEncryption = SecurityAlgorithm.AES;
                }
                else
                {
                    throw new Exception("SecurityKey size is not valid format");
                }
                _VivekSecurityKey = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public SecurityAlgorithm Encryption { get; private set; }
        public SecurityAlgorithm VivekEncryption { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerCode"></param>
        /// <param name="securityKey"></param>
        public ApiMoveContext(string consumerCode, string securityKey)
        {
            Client = new PublicServiceClient();
            Init(consumerCode, securityKey);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        public void ConfigureClient(string endpointConfigurationName)
        {
            Client = new Api.PublicServiceClient(endpointConfigurationName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public void ConfigureClient(string endpointConfigurationName, string remoteAddress)
        {
            Client = new Api.PublicServiceClient(endpointConfigurationName, remoteAddress);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="endpointConfigurationName"></param>
        /// <param name="remoteAddress"></param>
        public void ConfigureClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress)
        {
            Client = new Api.PublicServiceClient(endpointConfigurationName, remoteAddress);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="binding"></param>
        /// <param name="remoteAddress"></param>
        public void ConfigureClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress)
        {
            Client = new Api.PublicServiceClient(binding, remoteAddress);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerCode"></param>
        /// <param name="securityKey"></param>
        private void Init(string consumerCode, string securityKey)
        {
            ConsumerCode = consumerCode;
            SecurityKey = securityKey;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="OrderNumber"></param>
        /// <param name="ProductCode"></param>
        /// <param name="ClientOrderNumber"></param>
        /// <param name="RecipientSms"></param>
        /// <param name="RecipientEmail"></param>
        /// <param name="RecipientMemo"></param>
        /// <param name="RecipientName"></param>
        /// <param name="EmailSubject"></param>
        /// <param name="ActiveDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <returns></returns>
        public GetVoucherTransaction GetVoucher(string OrderNumber, string ProductCode,
            string ClientOrderNumber = null, string RecipientSms = null, string RecipientEmail = null,
            string RecipientMemo = null, string RecipientName = null, string EmailSubject = null,
            Nullable<DateTime> ActiveDate = null, Nullable<DateTime> ExpiryDate = null)
        {
            GetVoucherTransaction transaction = new GetVoucherTransaction();
            transaction.Request.OrderNumber = OrderNumber;
            transaction.Request.ProductCode = ProductCode;
            transaction.Request.ClientOrderNumber = ClientOrderNumber;
            transaction.Request.RecipientSms = RecipientSms;
            transaction.Request.RecipientEmail = RecipientEmail;
            transaction.Request.RecipientMemo = RecipientMemo;
            transaction.Request.RecipientName = RecipientName;
            transaction.Request.EmailSubject = EmailSubject;
            transaction.Request.ActiveDate = ActiveDate;
            transaction.Request.ExpiryDate = ExpiryDate;

            ExecuteTransaction(transaction);
            return transaction;
        }
        public GetVoucherV3Transaction GetVoucherV3(string OrderNumber, string ProductCode,
            string ClientOrderNumber = null, string RecipientSms = null, string RecipientEmail = null,
            string RecipientMemo = null, string RecipientName = null, string EmailSubject = null,
            Nullable<DateTime> ActiveDate = null, Nullable<DateTime> ExpiryDate = null)
        {
            GetVoucherV3Transaction transaction3 = new GetVoucherV3Transaction();
            transaction3.Request.OrderNumber = OrderNumber;
            transaction3.Request.ProductCode = ProductCode;
            transaction3.Request.ClientOrderNumber = ClientOrderNumber;
            transaction3.Request.RecipientSms = RecipientSms;
            transaction3.Request.RecipientEmail = RecipientEmail;
            transaction3.Request.RecipientMemo = RecipientMemo;
            transaction3.Request.RecipientName = RecipientName;
            transaction3.Request.EmailSubject = EmailSubject;
            transaction3.Request.ActiveDate = ActiveDate;
            transaction3.Request.ExpiryDate = ExpiryDate;

            ExecuteTransaction(transaction3);
            return transaction3;
        }

        public GetMultiVouchersV2Transaction GetMultiVouchersV2(string OrderNumber, string ClientOrderNumber, string ProductCode, int Quantity, float SoldPrice)
        {
            GetMultiVouchersV2Transaction transaction = new GetMultiVouchersV2Transaction();
            transaction.Request.OrderNumber = OrderNumber;
            transaction.Request.ClientOrderNumber = ClientOrderNumber;
            transaction.Request.ProductCode = ProductCode;
            transaction.Request.Quantity = Quantity;
            transaction.Request.SoldPrice = SoldPrice;

            ExecuteTransaction(transaction);
            return transaction;
        }

        public GetMultiVouchersV4Transaction GetMultiVouchersV4(string OrderNumber, string ClientOrderNumber, string ProductCode, int Quantity, float SoldPrice)
        {
            GetMultiVouchersV4Transaction transaction = new GetMultiVouchersV4Transaction();
            transaction.Request.OrderNumber = OrderNumber;
            transaction.Request.ClientOrderNumber = ClientOrderNumber;
            transaction.Request.ProductCode = ProductCode;
            transaction.Request.Quantity = Quantity;
            transaction.Request.SoldPrice = SoldPrice;

            ExecuteTransaction(transaction);
            return transaction;
        }


        /// <summary>
        /// This operation is used for client’s system to send voucher. RecipientSms or RecipientEmail must exist at least one.
        /// </summary>
        /// <param name="OrderNumber"></param>
        /// <param name="ProductCode"></param>
        /// <param name="ClientOrderNumber"></param>
        /// <param name="RecipientSms"></param>
        /// <param name="RecipientEmail"></param>
        /// <param name="RecipientMemo"></param>
        /// <param name="RecipientName"></param>
        /// <param name="EmailSubject"></param>
        /// <param name="ActiveDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <returns></returns>
        public SendVoucherTransaction SendVoucher(string OrderNumber, string ProductCode,
            string ClientOrderNumber = null, string RecipientSms = null, string RecipientEmail = null,
            string RecipientMemo = null, string RecipientName = null, string EmailSubject = null,
            Nullable<DateTime> ActiveDate = null, Nullable<DateTime> ExpiryDate = null)
        {
            SendVoucherTransaction transaction = new SendVoucherTransaction();
            transaction.Request.OrderNumber = OrderNumber;
            transaction.Request.ProductCode = ProductCode;
            transaction.Request.ClientOrderNumber = ClientOrderNumber;
            transaction.Request.RecipientSms = RecipientSms;
            transaction.Request.RecipientEmail = RecipientEmail;
            transaction.Request.RecipientMemo = RecipientMemo;
            transaction.Request.RecipientName = RecipientName;
            transaction.Request.EmailSubject = EmailSubject;
            transaction.Request.ActiveDate = ActiveDate;
            transaction.Request.ExpiryDate = ExpiryDate;

            ExecuteTransaction(transaction);
            return transaction;
        }

        /// <summary>
        /// This operation is used for client’s system to resend voucher.
        /// </summary>
        /// <param name="OrderNumber"></param>
        /// <param name="VoucherGuid"></param>
        /// <param name="DeliveryMethod"></param>
        /// <returns></returns>
        public ResendVoucherTransaction ResendVoucher(string OrderNumber, string VoucherGuid, VoucherDeliveryMethod DeliveryMethod)
        {
            return ResendVoucher(OrderNumber, Guid.Parse(VoucherGuid), DeliveryMethod);
        }

        /// <summary>
        /// This operation is used for client’s system to resend voucher.
        /// </summary>
        /// <param name="OrderNumber"></param>
        /// <param name="VoucherGuid"></param>
        /// <param name="DeliveryMethod"></param>
        /// <returns></returns>
        public ResendVoucherTransaction ResendVoucher(string OrderNumber, Guid VoucherGuid, VoucherDeliveryMethod DeliveryMethod)
        {
            ResendVoucherTransaction transaction = new ResendVoucherTransaction();
            transaction.Request.OrderNumber = OrderNumber;
            transaction.Request.VoucherGuid = VoucherGuid;
            transaction.Request.DeliveryMethod = DeliveryMethod;

            ExecuteTransaction(transaction);
            return transaction;
        }

        /// <summary>
        /// This operation is used for client’s system to trash a voucher.
        /// </summary>
        /// <param name="VoucherGuid"></param>
        /// <returns></returns>
        public TrashVoucherTransaction TrashVoucher(string VoucherGuid)
        {
            return TrashVoucher(Guid.Parse(VoucherGuid));
        }

        /// <summary>
        /// This operation is used for client’s system to trash a voucher.
        /// </summary>
        /// <param name="VoucherGuid"></param>
        /// <returns></returns>
        public TrashVoucherTransaction TrashVoucher(Guid VoucherGuid)
        {
            TrashVoucherTransaction transaction = new TrashVoucherTransaction();
            transaction.Request.VoucherGuid = VoucherGuid;

            ExecuteTransaction(transaction);
            return transaction;
        }

        /// <summary>
        /// This operation is used for client’s system to retrieve the status of a voucher.
        /// </summary>
        /// <param name="VoucherGuid"></param>
        /// <returns></returns>
        public QueryVoucherStatusTransaction QueryVoucherStatus(string VoucherGuid)
        {
            return QueryVoucherStatus(Guid.Parse(VoucherGuid));
        }

        /// <summary>
        /// This operation is used for client’s system to retrieve the status of a voucher.
        /// </summary>
        /// <param name="VoucherGuid"></param>
        /// <returns></returns>
        public QueryVoucherStatusTransaction QueryVoucherStatus(Guid VoucherGuid)
        {
            QueryVoucherStatusTransaction transaction = new QueryVoucherStatusTransaction();
            transaction.Request.VoucherGuid = VoucherGuid;

            ExecuteTransaction(transaction);
            return transaction;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="originalRequestGuid"></param>
        /// <returns></returns>
        public CheckOrderStatusTransaction CheckOrderStatus(string originalRequestGuid)
        {
            return CheckOrderStatus(Guid.Parse(originalRequestGuid));
        }

        /// <summary>
        /// This operation is used for client’s system to check the status of an order
        /// </summary>
        /// <param name="originalRequestGuid"></param>
        /// <returns></returns>
        public CheckOrderStatusTransaction CheckOrderStatus(Guid originalRequestGuid)
        {
            CheckOrderStatusTransaction transaction = new CheckOrderStatusTransaction();
            transaction.Request.OriginalRequestGuid = originalRequestGuid;

            ExecuteTransaction(transaction);
            return transaction;
        }

        /// <summary>
        /// Execute a transaction from the context
        /// </summary>
        /// <typeparam name="T1"></typeparam>
        /// <typeparam name="T2"></typeparam>
        /// <param name="transaction"></param>
        public void ExecuteTransaction<T1, T2>(Transaction<T1, T2> transaction)
            where T1 : RequestBase, new()
            where T2 : ResponseDto, new()
        {
            RequestDto dto = transaction.CreateRequestDto();
            string requestDtoXML = XmlSerializer<RequestDto>.ObjectToXml(dto);
            string encryptedRequestDto = DesHelper.Encrypt(requestDtoXML, SecurityKey, Encryption);
            string responseText = Client.Invoke(ConsumerCode, dto.OperationCode, encryptedRequestDto);
            if (!string.IsNullOrEmpty(responseText))
            {
                string decryptedResponse = DesHelper.Decrypt(responseText, SecurityKey, Encryption);
                transaction.ParseResponseOutDto(XmlSerializer<ResponseOutDto>.XmlToObject(decryptedResponse));
            }
            else
            {
                throw new Exception("Error response Empty");
            }
        }
    }
}
