﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class GetMultiVouchersResponseDtoV2 : ResponseDto
    {
        [DataMember]
        public string ProgramCode { get; set; }

        [DataMember]
        public List<VoucherBizApiResponseDto> Vouchers { get; set; }

        [DataMember]
        public Nullable<DateTime> ExpirationDate { get; set; }

        [DataMember]
        public string ProductName { get; set; }
    }
}
