﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class QueryVoucherStatusResponseDto : ResponseDto
    {
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public string MerchantCode { get; set; }
        [DataMember]
        public string ShopCode { get; set; }
        [DataMember]
        public string ConsumeDate { get; set; } //datetime 

    }
}
