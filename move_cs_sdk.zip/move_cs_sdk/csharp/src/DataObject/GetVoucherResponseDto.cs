﻿using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class GetVoucherResponseDto: ResponseDto
    {
        [DataMember]
        public string VoucherGuid { get; set; }

        [DataMember]
        public string ProgramCode { get; set; }

        [DataMember]
        public string VoucherNo { get; set; }

        [DataMember]
        public string ExpirationDate { get; set; }
    }
}
