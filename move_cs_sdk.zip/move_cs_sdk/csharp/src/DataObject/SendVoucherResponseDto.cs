﻿using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class SendVoucherResponseDto : GetVoucherResponseDto
    {
    }
}
