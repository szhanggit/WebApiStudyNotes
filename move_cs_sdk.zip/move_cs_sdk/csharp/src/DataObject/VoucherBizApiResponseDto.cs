﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class VoucherBizApiResponseDto
    {
        [DataMember]
        public string VoucherNo { get; set; }

        [DataMember]
        public List<VoucherBarcodeResponseDto> BarcodeInfo { get; set; }

        [DataMember]
        public string VoucherGuid { get; set; }
    }
}
