﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class VoucherBarcodeResponseDto
    {
        [DataMember]
        public string CodeValue { get; set; }

        [DataMember]
        public string CodeType { get; set; }

        [DataMember]
        public string Index { get; set; }
    }
}
