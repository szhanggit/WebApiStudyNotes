﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Tx2.Move.Utils;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class ResendVoucherRequestDto : RequestBase
    {
        [DataMember(IsRequired = true)]
        [RegularExpression(@"^20\d{2}(0[1-9]|1[0-2])(0[1-9]|[1-2]\d{1}|3[0-1])\d{4}$")]
        public string OrderNumber { get; set; }

        [DataMember(IsRequired = true)]
        public Guid VoucherGuid { get; set; }

        [DataMember(IsRequired = true)]
        public VoucherDeliveryMethod DeliveryMethod { get; set; }
    }
}
