﻿using System;
using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class CheckOrderStatusResponseDto: ResponseDto
    {
        [DataMember]
        public Guid VoucherGuid { get; set; }
        [DataMember]
        public string ProgramCode { get; set; }
        [DataMember]
        public string VoucherNo { get; set; }
        [DataMember]
        public string ClientOrderNumber { get; set; }

        [DataMember]
        public Nullable<DateTime> ExpirationDate { get; set; }
    }
}
