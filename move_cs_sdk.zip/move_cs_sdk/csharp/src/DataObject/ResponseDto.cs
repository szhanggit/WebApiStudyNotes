﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class ResponseDto
    {
        [DataMember]
        public string ResponseCode { get; set; }

        [DataMember]
        public string Message { get; set; }
    }
}