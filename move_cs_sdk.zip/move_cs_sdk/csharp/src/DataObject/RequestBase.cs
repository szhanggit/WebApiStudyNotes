﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class RequestBase
    {
        public string ConsumerCode { get; set; }

        public string RequestId { get; set; }
    }
}