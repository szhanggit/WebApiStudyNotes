﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class ResponseOutDto
    {
        [DataMember]
        public Guid RequestGuid { get; set; }
        [DataMember]
        public string Response { get; set; }
    }
}