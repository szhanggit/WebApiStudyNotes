﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class GetVoucherRequestDto : RequestBase
    {
        [DataMember(IsRequired = true)]
        [RegularExpression(@"^20\d{2}(0[0-9]|1[0-2])(0[0-9]|[1-2]\d{1}|3[0-1])\d{4}$")]
        public string OrderNumber { get; set; }

        [DataMember(IsRequired = true)]
        [RegularExpression("^[a-zA-Z0-9]{1,50}$")]
        public string ProductCode { get; set; }

        [DataMember(IsRequired = false)]
        public string ClientOrderNumber { get; set; }

        [DataMember(IsRequired = false)]
        public string RecipientSms { get; set; }

        [DataMember(IsRequired = false)]
        public string RecipientEmail { get; set; }

        [DataMember(IsRequired = false)]
        public string RecipientMemo { get; set; }

        [DataMember(IsRequired = false)]
        public string RecipientName { get; set; }

        [DataMember(IsRequired = false)]
        public string EmailSubject { get; set; }

        [DataMember]
        public Nullable<DateTime> ActiveDate { get; set; }
        [DataMember]
        public Nullable<DateTime> ExpiryDate { get; set; }
    }
}
