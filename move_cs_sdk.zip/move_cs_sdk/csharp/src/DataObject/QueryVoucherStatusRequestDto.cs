﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    public class QueryVoucherStatusRequestDto : RequestBase
    {
        [DataMember(IsRequired = true)]
        [Required]
        public Guid VoucherGuid { get; set; }
    }
}