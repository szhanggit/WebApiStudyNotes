﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class GetMultiVouchersRequestDto : RequestBase
    {
        [DataMember(IsRequired = true)]
        [RegularExpression(@"^20\d{2}(0[1-9]|1[0-2])(0[1-9]|[1-2]\d{1}|3[0-1])\d{4}$")]
        public string OrderNumber { get; set; }

        [DataMember(IsRequired = true)]
        [RegularExpression("^[a-zA-Z0-9]{1,50}$")]
        public string ProductCode { get; set; }

        [DataMember(IsRequired = false)]
        public string ClientOrderNumber { get; set; }

        [DataMember(IsRequired = true)]
        public float SoldPrice { get; set; }

        [DataMember(IsRequired = true)]
        public int Quantity { get; set; }

        [DataMember]
        public Nullable<DateTime> ActiveDate { get; set; }
    }
}
