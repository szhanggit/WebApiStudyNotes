﻿using System;
using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class VoucherGuidRequestDto : RequestBase
    {
        [DataMember]
        public Guid VoucherGuid { get; set; }
    }
}