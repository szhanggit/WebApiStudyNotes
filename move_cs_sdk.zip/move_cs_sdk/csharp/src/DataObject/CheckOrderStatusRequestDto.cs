﻿using System;
using System.Runtime.Serialization;

namespace Tx2.Move.DataObject
{
    [DataContract]
    public class CheckOrderStatusRequestDto: RequestBase
    {
        [DataMember(IsRequired = true)]
        public Guid OriginalRequestGuid { get; set; }
    }
}
